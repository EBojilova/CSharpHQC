﻿namespace LearningSystem.Models
{
    public enum Role
    {
        Student, 

        Lecturer

            // TODO: Add Guest
    }
}