﻿namespace LearningSystem
{
    using LearningSystem.Core;

    public class Program
    {
        public static void Main()
        {
            var egine = new Egine();
            egine.Run();
        }
    }
}