﻿namespace DOMBuilder
{
    public class Program
    {
        static void Main()
        {
            // TODO
        }
    }
}
