﻿namespace RPG.Weapons
{
    public class Axe
    {
    }
}
