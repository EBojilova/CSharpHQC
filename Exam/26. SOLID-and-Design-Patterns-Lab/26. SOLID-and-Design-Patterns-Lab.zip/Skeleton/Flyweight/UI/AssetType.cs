﻿namespace ReaperInvasion.UI
{
    public enum AssetType
    {
        Reaper
    }
}
