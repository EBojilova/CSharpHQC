﻿namespace BuhtigIssueTracker.Interfaces
{
    internal interface IEngine
    {
        void Run();
    }
}