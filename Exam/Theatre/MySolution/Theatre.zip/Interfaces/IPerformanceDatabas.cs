﻿// Do not modify the interface members
// Moving the interface to separate namespace is allowed
// Adding XML documentation is allowed
// TODO: document this interface definition

namespace Theatre.Interfaces
{
    using System;
    using System.Collections.Generic;

    /// <summary>
    /// Provides the basic operations required to run a vehicle park.
    /// </summary>
    internal interface IPerformanceDatabase
    {
        /// <summary>
        /// Adds a theatre by given theatre name. The theatre name is unique among all theatres.
        /// </summary>
        /// <param name="theatreName">The name of the theatre.</param>
        void AddTheatre(string theatreName);

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        IEnumerable<string> ListTheatres();

        /// <summary>
        /// 
        /// </summary>
        /// <param name="theatreName"></param>
        /// <param name="performanceTitle"></param>
        /// <param name="startDateTime"></param>
        /// <param name="duration"></param>
        /// <param name="price"></param>
        void AddPerformance(
            string theatreName,
            string performanceTitle,
            DateTime startDateTime,
            TimeSpan duration,
            decimal price);

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        IEnumerable<Performance> ListAllPerformances();

        /// <summary>
        /// 
        /// </summary>
        /// <param name="theatreName"></param>
        /// <returns></returns>
        IEnumerable<Performance> ListPerformances(string theatreName);
    }
}