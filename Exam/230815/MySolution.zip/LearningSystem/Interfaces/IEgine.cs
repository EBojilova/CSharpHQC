﻿namespace LearningSystem.Interfaces
{
    public interface IEgine
    {
        void Run();
    }
}