﻿namespace LearningSystem.Models
{
    public enum Role
    {
        Student, 

        Lecturer
    }
}