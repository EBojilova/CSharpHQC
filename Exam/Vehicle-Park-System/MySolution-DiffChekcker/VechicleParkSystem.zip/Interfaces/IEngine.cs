﻿namespace VechicleParkSystem.Interfaces
{
    internal interface IEngine
    {
        void Run();
    }
}