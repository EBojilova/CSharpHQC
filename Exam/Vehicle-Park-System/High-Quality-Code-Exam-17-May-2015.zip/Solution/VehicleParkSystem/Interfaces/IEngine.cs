﻿namespace VehicleParkSystem.Interfaces
{
    public interface IEngine
    {
        void Run();
    }
}
