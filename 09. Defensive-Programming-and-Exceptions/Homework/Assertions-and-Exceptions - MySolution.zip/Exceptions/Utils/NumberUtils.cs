﻿namespace Exceptions_Homework.Utils
{
    using System;

    internal static class NumberUtils
    {
        public static bool CheckPrime(int number)
        {
            if (number < 2)
            {
                return false;
            }

            for (var divisor = 2; divisor <= Math.Sqrt(number); divisor++)
            {
                if (number % divisor == 0)
                {
                    return false;
                }
            }

            return true;
        }
    }
}