﻿namespace Exceptions_Homework.Exams
{
    public abstract class Exam
    {
        public abstract ExamResult Check();
    }
}